﻿function func() {
$("input:checked").css("border", "lpx solid green");
}
