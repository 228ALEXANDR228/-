function func() {
	height=$("#texxt").height();
	$("#texxt").height(height*2);
	width=$("#texxt").width();
	$("#texxt").width(width*2);
	

}	