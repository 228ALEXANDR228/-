function func(){
$("#log").css("border","2px solid green");
$("#pas1").css("border","2px solid red");
$("#pas2").css("border","2px solid blue");
}